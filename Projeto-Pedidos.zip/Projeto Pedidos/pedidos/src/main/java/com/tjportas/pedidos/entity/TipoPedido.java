package com.tjportas.pedidos.entity;

public enum TipoPedido {
ORÇAMENTO, VENDA, TROCA, DEVOLUÇÃO, CANCELAMENTO;

}
